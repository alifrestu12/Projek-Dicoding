import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load datasets
hour_df = pd.read_csv("D:\latihan python\streamlit_basic\hour_df.csv")
day_df = pd.read_csv("D:\latihan python\streamlit_basic\day_df.csv")

# Set Streamlit page config
st.set_page_config(page_title="Bike Sharing Dashboard", layout="wide")

# Dashboard title
st.title("Bike Sharing Dashboard")

# Sidebar navigation
menu = st.sidebar.radio("Navigation", [
    "Overview",
    "Seasonal Analysis",
    "Hourly Analysis",
    "Holiday Impact",
    "Weather Impact"
])

# Overview Section
if menu == "Overview":
    st.header("Overview")
    total_rentals = day_df["cnt"].sum()
    avg_temp = day_df["temp"].mean() * 47 - 8
    avg_humidity = day_df["hum"].mean() * 100

    col1, col2, col3 = st.columns(3)
    col1.metric("Total Rentals", f"{total_rentals:,}")
    col2.metric("Avg Temperature (°C)", f"{avg_temp:.1f}")
    col3.metric("Avg Humidity (%)", f"{avg_humidity:.1f}")

    st.subheader("Sample Data")
    st.dataframe(day_df.head())

# Seasonal Analysis
elif menu == "Seasonal Analysis":
    st.header("Seasonal Analysis")
    seasonal_rentals = day_df.groupby('season')["cnt"].sum().sort_values(ascending=False)

    fig, ax = plt.subplots(figsize=(6, 5))
    sns.barplot(x=seasonal_rentals.index, y=seasonal_rentals.values, palette="Blues_r", ax=ax)
    ax.set_title("Jumlah Penyewaan Sepeda Berdasarkan Musim", fontsize=10)
    ax.set_xlabel("Musim", fontsize=9)
    ax.set_ylabel("Jumlah Penyewaan", fontsize=9)
    ax.grid(axis='y', linestyle='--', alpha=0.7)

    st.pyplot(fig)

# Hourly Analysis
elif menu == "Hourly Analysis":
    st.header("Hourly Analysis")
    hourly_rentals = hour_df.groupby("hr")["cnt"].sum().reset_index()

    fig, ax = plt.subplots(figsize=(6, 4))
    sns.lineplot(data=hourly_rentals, x="hr", y="cnt", marker="o", color="b", ax=ax)
    ax.set_title("Jumlah Penyewaan Sepeda Berdasarkan Jam", fontsize=10)
    ax.set_xlabel("Jam (hr)", fontsize=9)
    ax.set_ylabel("Jumlah Rental Sepeda", fontsize=9)
    ax.grid(axis='y', linestyle='-', alpha=0.7)

    st.pyplot(fig)

# Holiday Impact
elif menu == "Holiday Impact":
    st.header("Impact of Holidays")
    holiday_rentals = day_df.groupby('holiday')["cnt"].sum().reset_index()
    holiday_rentals["holiday"] = holiday_rentals["holiday"].map({0: "Hari Kerja", 1: "Hari Libur"})

    fig, ax = plt.subplots(figsize=(6, 4))
    sns.barplot(data=holiday_rentals, x="holiday", y="cnt", palette="Blues_r", ax=ax)
    ax.set_title("Jumlah Penyewaan Sepeda Berdasarkan Hari Kerja dan Hari Libur", fontsize=10)
    ax.set_xlabel("Kategori Hari", fontsize=9)
    ax.set_ylabel("Jumlah Rental Sepeda", fontsize=9)
    ax.grid(axis='y', linestyle='--')

    st.pyplot(fig)

# Weather Impact
elif menu == "Weather Impact":
    st.header("Impact of Weather")
    weather_rentals = hour_df.groupby("weathersit")["cnt"].sum().reset_index()
    weather_labels = {
        1: "Clear/Few Clouds",
        2: "Mist/Cloudy",
        3: "Light Snow/Rain",
        4: "Heavy Rain/Snow"
    }
    weather_rentals["weathersit"] = weather_rentals["weathersit"].replace(weather_labels)

    fig, ax = plt.subplots(figsize=(6,4))
    sns.barplot(data=weather_rentals, x="weathersit", y="cnt", palette="Paired", ax=ax)
    ax.set_title("Jumlah Penyewaan Sepeda Berdasarkan Kondisi Cuaca", fontsize=10)
    ax.set_xlabel("Kondisi Cuaca", fontsize=9)
    ax.set_ylabel("Jumlah Penyewaan", fontsize=9)
    ax.grid(axis='y', linestyle='--')

    st.pyplot(fig)
